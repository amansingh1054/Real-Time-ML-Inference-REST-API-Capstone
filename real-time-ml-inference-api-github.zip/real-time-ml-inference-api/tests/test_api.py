from fastapi.testclient import TestClient
from app.main import app, FEATURE_NAMES

client = TestClient(app)

def valid_payload():
    return {"features": {name: 0.25 for name in FEATURE_NAMES}}

def test_health_returns_ok():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_predict_returns_valid_schema():
    response = client.post("/predict", json=valid_payload())
    assert response.status_code == 200
    body = response.json()
    assert body["prediction"] in (0, 1)
    assert set(body["probabilities"].keys()) == {"0", "1"}
    assert abs(sum(body["probabilities"].values()) - 1.0) < 1e-6
    assert body["model_version"]

def test_missing_feature_returns_422():
    payload = valid_payload()
    payload["features"].pop(FEATURE_NAMES[0])
    response = client.post("/predict", json=payload)
    assert response.status_code == 422
    assert "Missing features" in response.json()["detail"]

def test_unknown_feature_returns_422():
    payload = valid_payload()
    payload["features"]["unknown_feature"] = 10
    response = client.post("/predict", json=payload)
    assert response.status_code == 422
    assert "Unknown features" in response.json()["detail"]

def test_invalid_payload_returns_422():
    response = client.post("/predict", json={"features": "not-a-dictionary"})
    assert response.status_code == 422
