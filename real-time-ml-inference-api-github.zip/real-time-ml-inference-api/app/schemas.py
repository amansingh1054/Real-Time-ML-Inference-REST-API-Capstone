from pydantic import BaseModel, Field, ConfigDict
from typing import Dict

class PredictionRequest(BaseModel):
    """Named numeric feature values for one inference request."""
    model_config = ConfigDict(extra="forbid")
    features: Dict[str, float] = Field(
        ..., min_length=1,
        examples=[{
            "feature_1": 0.2,
            "feature_2": -1.1,
            "feature_3": 1.4,
            "feature_4": 0.7,
            "feature_5": -0.3,
            "feature_6": 0.9
        }]
    )

class PredictionResponse(BaseModel):
    prediction: int = Field(..., ge=0, le=1)
    probabilities: Dict[str, float]
    model_version: str
