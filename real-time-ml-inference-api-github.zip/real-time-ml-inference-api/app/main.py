import json
import os
from pathlib import Path
from typing import Any

import joblib
import numpy as np
from fastapi import FastAPI, HTTPException
from app.schemas import PredictionRequest, PredictionResponse

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = Path(os.getenv("MODEL_PATH", ROOT / "models" / "champion_model.joblib"))
FEATURES_PATH = Path(os.getenv("FEATURES_PATH", ROOT / "models" / "feature_names.json"))
MODEL_VERSION = os.getenv("MODEL_VERSION", "1.0.0")

app = FastAPI(
    title="Real-Time ML Inference API",
    description=(
        "A sample production-style binary-classification service. "
        "Send six named numeric features to `/predict` to receive a class "
        "prediction and class probabilities."
    ),
    version=MODEL_VERSION,
)

try:
    model = joblib.load(MODEL_PATH)
    with FEATURES_PATH.open("r", encoding="utf-8") as f:
        FEATURE_NAMES = json.load(f)
except Exception as exc:
    raise RuntimeError(
        f"Could not load model artifacts. Expected model at {MODEL_PATH} "
        f"and feature list at {FEATURES_PATH}: {exc}"
    ) from exc

@app.get("/health", tags=["Operations"])
def health() -> dict[str, str]:
    """Liveness check for containers and orchestration."""
    return {"status": "ok", "model_version": MODEL_VERSION}

@app.get("/", tags=["Operations"])
def root() -> dict[str, str]:
    return {
        "service": "Real-Time ML Inference API",
        "docs": "/docs",
        "health": "/health",
    }

@app.post("/predict", response_model=PredictionResponse, tags=["Inference"])
def predict(request: PredictionRequest) -> PredictionResponse:
    """Return a binary prediction and model-estimated class probabilities."""
    received = set(request.features.keys())
    expected = set(FEATURE_NAMES)
    missing = sorted(expected - received)
    extra = sorted(received - expected)

    if missing or extra:
        details = []
        if missing:
            details.append(f"Missing features: {', '.join(missing)}")
        if extra:
            details.append(f"Unknown features: {', '.join(extra)}")
        raise HTTPException(status_code=422, detail="; ".join(details))

    values = [request.features[name] for name in FEATURE_NAMES]
    if not np.all(np.isfinite(values)):
        raise HTTPException(status_code=422, detail="Feature values must be finite numbers")

    try:
        row = np.asarray(values, dtype=float).reshape(1, -1)
        predicted = int(model.predict(row)[0])
        raw_probabilities = model.predict_proba(row)[0]
        probabilities = {
            str(int(label)): float(probability)
            for label, probability in zip(model.classes_, raw_probabilities)
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Prediction failed") from exc

    return PredictionResponse(
        prediction=predicted,
        probabilities=probabilities,
        model_version=MODEL_VERSION,
    )
